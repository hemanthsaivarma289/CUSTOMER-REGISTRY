const asyncHandler = require("express-async-handler");
const bcrypt = require("bcryptjs");
const User = require("../models/UserModel");
const generateToken = require("../utils/generateToken");

// @desc Register user  @route POST /api/users/register
const registerUser = asyncHandler(async (req, res) => {
  const { name, email, password, phone, address } = req.body;
  if (!name || !email || !password) {
    res.status(400);
    throw new Error("Please provide name, email, password");
  }
  if (await User.findOne({ email })) {
    res.status(400);
    throw new Error("User already exists");
  }
  const hashed = await bcrypt.hash(password, 10);
  const count = await User.countDocuments();
  const user = await User.create({
    name,
    email,
    password: hashed,
    phone,
    address,
    role: count === 0 ? "admin" : "user",
  });
  res.status(201).json({
    _id: user._id,
    name: user.name,
    email: user.email,
    role: user.role,
    token: generateToken(user._id),
  });
});

// @desc Login  @route POST /api/users/login
const loginUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (user && (await bcrypt.compare(password, user.password))) {
    return res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: generateToken(user._id),
    });
  }
  res.status(401);
  throw new Error("Invalid credentials");
});

// @desc Current profile  @route GET /api/users/me
const getMe = asyncHandler(async (req, res) => res.json(req.user));

// @desc Update profile  @route PUT /api/users/me
const updateMe = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id);
  if (!user) {
    res.status(404);
    throw new Error("User not found");
  }
  user.name = req.body.name || user.name;
  user.phone = req.body.phone ?? user.phone;
  user.address = req.body.address ?? user.address;
  await user.save();
  res.json(user);
});

module.exports = { registerUser, loginUser, getMe, updateMe };
