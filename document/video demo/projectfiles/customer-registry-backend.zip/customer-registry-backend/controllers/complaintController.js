const asyncHandler = require("express-async-handler");
const Complaint = require("../models/ComplaintModel");

// @desc Create complaint  @route POST /api/complaints
const createComplaint = asyncHandler(async (req, res) => {
  const { customerName, email, phone, category, subject, description } = req.body;
  if (!customerName || !email || !phone || !category || !subject || !description) {
    res.status(400);
    throw new Error("All fields are required");
  }
  const complaint = await Complaint.create({
    user: req.user._id,
    customerName,
    email,
    phone,
    category,
    subject,
    description,
  });
  res.status(201).json(complaint);
});

// @desc My complaints  @route GET /api/complaints
const getMyComplaints = asyncHandler(async (req, res) => {
  const rows = await Complaint.find({ user: req.user._id }).sort({ createdAt: -1 });
  res.json(rows);
});

// @desc All complaints (admin)  @route GET /api/complaints/all
const getAllComplaints = asyncHandler(async (_req, res) => {
  const rows = await Complaint.find().sort({ createdAt: -1 }).populate("user", "name email");
  res.json(rows);
});

// @desc One complaint  @route GET /api/complaints/:id
const getComplaintById = asyncHandler(async (req, res) => {
  const c = await Complaint.findById(req.params.id);
  if (!c) {
    res.status(404);
    throw new Error("Complaint not found");
  }
  if (req.user.role !== "admin" && c.user.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error("Not authorized");
  }
  res.json(c);
});

// @desc Update status/reply (admin)  @route PUT /api/complaints/:id
const updateComplaint = asyncHandler(async (req, res) => {
  const c = await Complaint.findById(req.params.id);
  if (!c) {
    res.status(404);
    throw new Error("Complaint not found");
  }
  c.status = req.body.status || c.status;
  c.adminReply = req.body.adminReply ?? c.adminReply;
  await c.save();
  res.json(c);
});

// @desc Delete (admin)  @route DELETE /api/complaints/:id
const deleteComplaint = asyncHandler(async (req, res) => {
  const c = await Complaint.findById(req.params.id);
  if (!c) {
    res.status(404);
    throw new Error("Complaint not found");
  }
  await c.deleteOne();
  res.json({ message: "Complaint removed" });
});

module.exports = {
  createComplaint,
  getMyComplaints,
  getAllComplaints,
  getComplaintById,
  updateComplaint,
  deleteComplaint,
};
