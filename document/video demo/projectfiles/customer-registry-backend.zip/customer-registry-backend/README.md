# Customer Registry System — Backend

Node.js + Express + MongoDB (Mongoose) REST API for managing customer complaints.

## Structure
```
customer-registry-backend/
├── config/db.js
├── controllers/
│   ├── userController.js
│   └── complaintController.js
├── middleware/
│   ├── authMiddleware.js
│   └── errorMiddleware.js
├── models/
│   ├── UserModel.js
│   └── ComplaintModel.js
├── routes/
│   ├── userRoutes.js
│   └── complaintRoutes.js
├── utils/generateToken.js
├── server.js
├── .env.example
└── package.json
```

## Setup
```bash
npm install
cp .env.example .env   # then edit MONGO_URI, JWT_SECRET
npm run dev
```

## API Endpoints

### Users
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST | /api/users/register | Public | Register (first user becomes admin) |
| POST | /api/users/login | Public | Login, returns JWT |
| GET  | /api/users/me | Private | Current profile |
| PUT  | /api/users/me | Private | Update profile |

### Complaints
| Method | Endpoint | Access | Description |
|--------|----------|--------|-------------|
| POST   | /api/complaints | Private | Register complaint |
| GET    | /api/complaints | Private | My complaints |
| GET    | /api/complaints/all | Admin | All complaints |
| GET    | /api/complaints/:id | Owner/Admin | One complaint |
| PUT    | /api/complaints/:id | Admin | Update status/reply |
| DELETE | /api/complaints/:id | Admin | Delete |

Send `Authorization: Bearer <token>` on protected routes.

## Categories
Technical Issue · Billing Issue · Account Issue · Service Request · General Query

## Statuses
Pending · In Progress · Resolved
