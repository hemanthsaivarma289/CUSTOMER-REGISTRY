const express = require("express");
const router = express.Router();
const {
  createComplaint,
  getMyComplaints,
  getAllComplaints,
  getComplaintById,
  updateComplaint,
  deleteComplaint,
} = require("../controllers/complaintController");
const { protect, admin } = require("../middleware/authMiddleware");

router.route("/").post(protect, createComplaint).get(protect, getMyComplaints);
router.get("/all", protect, admin, getAllComplaints);
router
  .route("/:id")
  .get(protect, getComplaintById)
  .put(protect, admin, updateComplaint)
  .delete(protect, admin, deleteComplaint);

module.exports = router;
