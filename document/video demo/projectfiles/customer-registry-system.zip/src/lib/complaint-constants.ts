export const CATEGORIES = [
  "Technical Issue",
  "Billing Issue",
  "Account Issue",
  "Service Request",
  "General Query",
] as const;

export const STATUSES = ["Pending", "In Progress", "Resolved"] as const;

export type ComplaintCategory = (typeof CATEGORIES)[number];
export type ComplaintStatus = (typeof STATUSES)[number];

export function statusColor(status: ComplaintStatus): string {
  switch (status) {
    case "Pending":
      return "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200";
    case "In Progress":
      return "bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-200";
    case "Resolved":
      return "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200";
  }
}
