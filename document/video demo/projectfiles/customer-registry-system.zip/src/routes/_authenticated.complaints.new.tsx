import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { CATEGORIES, type ComplaintCategory } from "@/lib/complaint-constants";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/complaints/new")({
  head: () => ({ meta: [{ title: "Register Complaint — Customer Registry" }] }),
  component: NewComplaint,
});

function NewComplaint() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [f, setF] = useState({
    customer_name: "",
    email: "",
    phone: "",
    category: "" as ComplaintCategory | "",
    subject: "",
    description: "",
  });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!user) return;
    void supabase
      .from("profiles")
      .select("full_name,email,phone")
      .eq("id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data) {
          setF((prev) => ({
            ...prev,
            customer_name: prev.customer_name || data.full_name || "",
            email: prev.email || data.email || user.email || "",
            phone: prev.phone || data.phone || "",
          }));
        }
      });
  }, [user]);

  return (
    <AppShell>
      <div className="mx-auto max-w-2xl px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Register Complaint</CardTitle>
          </CardHeader>
          <CardContent>
            <form
              className="space-y-4"
              onSubmit={async (e) => {
                e.preventDefault();
                if (!user || !f.category) return;
                setBusy(true);
                const { error } = await supabase.from("complaints").insert({
                  user_id: user.id,
                  customer_name: f.customer_name,
                  email: f.email,
                  phone: f.phone,
                  category: f.category,
                  subject: f.subject,
                  description: f.description,
                });
                setBusy(false);
                if (error) toast.error(error.message);
                else {
                  toast.success("Complaint registered");
                  void navigate({ to: "/dashboard" });
                }
              }}
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="cn">Customer Name</Label>
                  <Input
                    id="cn"
                    value={f.customer_name}
                    required
                    onChange={(e) => setF({ ...f, customer_name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ce">Email</Label>
                  <Input
                    id="ce"
                    type="email"
                    value={f.email}
                    required
                    onChange={(e) => setF({ ...f, email: e.target.value })}
                  />
                </div>
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="cp">Phone Number</Label>
                  <Input
                    id="cp"
                    type="tel"
                    value={f.phone}
                    required
                    onChange={(e) => setF({ ...f, phone: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cc">Complaint Category</Label>
                  <Select
                    value={f.category}
                    onValueChange={(v) => setF({ ...f, category: v as ComplaintCategory })}
                  >
                    <SelectTrigger id="cc">
                      <SelectValue placeholder="Choose category" />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map((c) => (
                        <SelectItem key={c} value={c}>
                          {c}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="cs">Complaint Subject</Label>
                <Input
                  id="cs"
                  value={f.subject}
                  required
                  onChange={(e) => setF({ ...f, subject: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="cd">Complaint Description</Label>
                <Textarea
                  id="cd"
                  rows={5}
                  value={f.description}
                  required
                  onChange={(e) => setF({ ...f, description: e.target.value })}
                />
              </div>
              <Button type="submit" disabled={busy || !f.category} className="w-full">
                {busy ? "Submitting…" : "Register Complaint"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
