import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { STATUSES, type ComplaintStatus, statusColor } from "@/lib/complaint-constants";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Manage Complaints — Admin" }] }),
  component: Admin,
});

type Row = {
  id: string;
  customer_name: string;
  email: string;
  phone: string;
  category: string;
  subject: string;
  description: string;
  status: ComplaintStatus;
  admin_reply: string | null;
  created_at: string;
};

function Admin() {
  const { isAdmin, loading } = useAuth();
  const navigate = useNavigate();
  const [rows, setRows] = useState<Row[]>([]);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const { data } = await supabase
      .from("complaints")
      .select("*")
      .order("created_at", { ascending: false });
    setRows((data ?? []) as Row[]);
  }, []);

  useEffect(() => {
    if (!loading && !isAdmin) void navigate({ to: "/dashboard" });
    if (isAdmin) void load();
  }, [isAdmin, loading, navigate, load]);

  if (!isAdmin) return null;

  return (
    <AppShell>
      <div className="mx-auto max-w-4xl px-4 py-8">
        <h1 className="mb-6 text-2xl font-bold text-foreground">Manage Complaints</h1>
        {rows.length === 0 ? (
          <p className="text-muted-foreground">No complaints yet.</p>
        ) : (
          <div className="space-y-4">
            {rows.map((r) => (
              <Card key={r.id}>
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <CardTitle className="text-base">{r.subject}</CardTitle>
                      <p className="mt-1 text-xs text-muted-foreground">
                        {r.customer_name} · {r.email} · {r.phone}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {r.category} · {new Date(r.created_at).toLocaleString()}
                      </p>
                    </div>
                    <span
                      className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-medium ${statusColor(r.status)}`}
                    >
                      {r.status}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <p className="whitespace-pre-wrap text-foreground">{r.description}</p>
                  <Textarea
                    placeholder="Admin reply…"
                    defaultValue={r.admin_reply ?? ""}
                    onBlur={(e) => {
                      setRows((prev) =>
                        prev.map((x) =>
                          x.id === r.id ? { ...x, admin_reply: e.target.value } : x,
                        ),
                      );
                    }}
                    rows={2}
                  />
                  <div className="flex flex-wrap items-center gap-2">
                    <Select
                      value={r.status}
                      onValueChange={(v) =>
                        setRows((prev) =>
                          prev.map((x) =>
                            x.id === r.id ? { ...x, status: v as ComplaintStatus } : x,
                          ),
                        )
                      }
                    >
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {STATUSES.map((s) => (
                          <SelectItem key={s} value={s}>
                            {s}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button
                      size="sm"
                      disabled={busy}
                      onClick={async () => {
                        setBusy(true);
                        const { error } = await supabase
                          .from("complaints")
                          .update({
                            status: r.status,
                            admin_reply: r.admin_reply,
                          })
                          .eq("id", r.id);
                        setBusy(false);
                        if (error) toast.error(error.message);
                        else toast.success("Updated");
                      }}
                    >
                      Save
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      disabled={busy}
                      onClick={async () => {
                        if (!confirm("Delete this complaint?")) return;
                        setBusy(true);
                        const { error } = await supabase
                          .from("complaints")
                          .delete()
                          .eq("id", r.id);
                        setBusy(false);
                        if (error) toast.error(error.message);
                        else {
                          toast.success("Deleted");
                          void load();
                        }
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
