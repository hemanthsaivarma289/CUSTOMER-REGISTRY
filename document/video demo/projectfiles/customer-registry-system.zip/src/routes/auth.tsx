import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — Customer Registry" },
      { name: "description", content: "Sign in or create an account to register complaints." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (!loading && user) void navigate({ to: "/dashboard" });
  }, [user, loading, navigate]);

  return (
    <AppShell>
      <div className="mx-auto flex max-w-md flex-col px-4 py-12">
        <h1 className="mb-6 text-center text-2xl font-bold text-foreground">Customer Registry</h1>
        <Tabs defaultValue="signin" className="w-full">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="signin">Sign in</TabsTrigger>
            <TabsTrigger value="signup">Register</TabsTrigger>
          </TabsList>
          <TabsContent value="signin">
            <SignInForm />
          </TabsContent>
          <TabsContent value="signup">
            <SignUpForm />
          </TabsContent>
        </Tabs>
        <p className="mt-6 text-center text-xs text-muted-foreground">
          <Link to="/" className="hover:underline">
            ← Back home
          </Link>
        </p>
      </div>
    </AppShell>
  );
}

function SignInForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Welcome back</CardTitle>
        <CardDescription>Sign in to manage your complaints.</CardDescription>
      </CardHeader>
      <CardContent>
        <form
          className="space-y-4"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            const { error } = await supabase.auth.signInWithPassword({ email, password });
            setBusy(false);
            if (error) toast.error(error.message);
            else toast.success("Signed in");
          }}
        >
          <div className="space-y-2">
            <Label htmlFor="si-email">Email</Label>
            <Input
              id="si-email"
              type="email"
              value={email}
              required
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="si-pw">Password</Label>
            <Input
              id="si-pw"
              type="password"
              value={password}
              required
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <Button type="submit" disabled={busy} className="w-full">
            {busy ? "Signing in…" : "Sign in"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

function SignUpForm() {
  const [f, setF] = useState({
    email: "",
    password: "",
    full_name: "",
    phone: "",
    address: "",
  });
  const [busy, setBusy] = useState(false);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create an account</CardTitle>
        <CardDescription>Register to file complaints and track them.</CardDescription>
      </CardHeader>
      <CardContent>
        <form
          className="space-y-4"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            const { error } = await supabase.auth.signUp({
              email: f.email,
              password: f.password,
              options: {
                emailRedirectTo: `${window.location.origin}/dashboard`,
                data: {
                  full_name: f.full_name,
                  phone: f.phone,
                  address: f.address,
                },
              },
            });
            setBusy(false);
            if (error) toast.error(error.message);
            else toast.success("Account created — you're signed in");
          }}
        >
          <div className="space-y-2">
            <Label htmlFor="su-name">Full name</Label>
            <Input
              id="su-name"
              value={f.full_name}
              required
              onChange={(e) => setF({ ...f, full_name: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="su-email">Email</Label>
            <Input
              id="su-email"
              type="email"
              value={f.email}
              required
              onChange={(e) => setF({ ...f, email: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="su-phone">Phone number</Label>
            <Input
              id="su-phone"
              type="tel"
              value={f.phone}
              required
              onChange={(e) => setF({ ...f, phone: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="su-addr">Address (optional)</Label>
            <Textarea
              id="su-addr"
              value={f.address}
              onChange={(e) => setF({ ...f, address: e.target.value })}
              rows={2}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="su-pw">Password</Label>
            <Input
              id="su-pw"
              type="password"
              value={f.password}
              required
              minLength={6}
              onChange={(e) => setF({ ...f, password: e.target.value })}
            />
          </div>
          <Button type="submit" disabled={busy} className="w-full">
            {busy ? "Creating account…" : "Create account"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
