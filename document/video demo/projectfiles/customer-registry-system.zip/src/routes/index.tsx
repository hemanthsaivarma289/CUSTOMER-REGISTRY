import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { ClipboardList, ShieldCheck, Users } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Customer Registry System" },
      {
        name: "description",
        content:
          "Register and track customer complaints. Fast intake, clear status, and quick resolutions.",
      },
      { property: "og:title", content: "Customer Registry System" },
      {
        property: "og:description",
        content: "Register and track customer complaints with ease.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <AppShell>
      <section className="mx-auto max-w-4xl px-4 py-20 text-center">
        <div className="mx-auto mb-6 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
          <ClipboardList className="h-7 w-7" />
        </div>
        <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
          Customer Registry System
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">
          Register complaints, track progress, and get resolutions — all in one place.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Button asChild size="lg">
            <Link to="/auth">Get started</Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link to="/dashboard">My Complaints</Link>
          </Button>
        </div>

        <div className="mt-16 grid gap-6 sm:grid-cols-3">
          {[
            {
              icon: <ClipboardList className="h-5 w-5" />,
              title: "Register",
              body: "Log complaints in seconds with the right category.",
            },
            {
              icon: <Users className="h-5 w-5" />,
              title: "Track",
              body: "See status: Pending, In Progress, or Resolved.",
            },
            {
              icon: <ShieldCheck className="h-5 w-5" />,
              title: "Resolve",
              body: "Admins reply and update status transparently.",
            },
          ].map((f) => (
            <div key={f.title} className="rounded-xl border bg-card p-6 text-left">
              <div className="mb-3 inline-flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                {f.icon}
              </div>
              <h3 className="font-semibold text-foreground">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.body}</p>
            </div>
          ))}
        </div>
      </section>
    </AppShell>
  );
}
