import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { statusColor } from "@/lib/complaint-constants";
import { Plus, FileText } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "My Complaints — Customer Registry" }] }),
  component: Dashboard,
});

type Complaint = {
  id: string;
  subject: string;
  category: string;
  status: "Pending" | "In Progress" | "Resolved";
  created_at: string;
};

function Dashboard() {
  const { user } = useAuth();
  const [rows, setRows] = useState<Complaint[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    void supabase
      .from("complaints")
      .select("id,subject,category,status,created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        setRows((data ?? []) as Complaint[]);
        setLoading(false);
      });
  }, [user]);

  return (
    <AppShell>
      <div className="mx-auto max-w-4xl px-4 py-8">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">My Complaints</h1>
            <p className="text-sm text-muted-foreground">Track your registered complaints.</p>
          </div>
          <Button asChild>
            <Link to="/complaints/new">
              <Plus className="mr-1 h-4 w-4" /> Register Complaint
            </Link>
          </Button>
        </div>

        {loading ? (
          <p className="text-muted-foreground">Loading…</p>
        ) : rows.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <FileText className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
              <p className="text-muted-foreground">No complaints yet.</p>
              <Button asChild className="mt-4">
                <Link to="/complaints/new">Register your first complaint</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {rows.map((c) => (
              <Link
                key={c.id}
                to="/complaints/$id"
                params={{ id: c.id }}
                className="block"
              >
                <Card className="transition hover:border-primary/50">
                  <CardContent className="flex items-center justify-between gap-4 p-4">
                    <div className="min-w-0">
                      <p className="truncate font-medium text-foreground">{c.subject}</p>
                      <p className="mt-1 text-xs text-muted-foreground">
                        {c.category} · {new Date(c.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <span
                      className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-medium ${statusColor(c.status)}`}
                    >
                      {c.status}
                    </span>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}
