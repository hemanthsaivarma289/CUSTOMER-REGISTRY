import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { statusColor } from "@/lib/complaint-constants";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/_authenticated/complaints/$id")({
  head: () => ({ meta: [{ title: "Complaint Details — Customer Registry" }] }),
  component: Details,
});

type Complaint = {
  id: string;
  customer_name: string;
  email: string;
  phone: string;
  category: string;
  subject: string;
  description: string;
  status: "Pending" | "In Progress" | "Resolved";
  admin_reply: string | null;
  created_at: string;
};

function Details() {
  const { id } = Route.useParams();
  const [c, setC] = useState<Complaint | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    void supabase
      .from("complaints")
      .select("*")
      .eq("id", id)
      .maybeSingle()
      .then(({ data }) => {
        setC(data as Complaint | null);
        setLoading(false);
      });
  }, [id]);

  return (
    <AppShell>
      <div className="mx-auto max-w-2xl px-4 py-8">
        <Button asChild variant="ghost" size="sm" className="mb-4">
          <Link to="/dashboard">
            <ArrowLeft className="mr-1 h-4 w-4" /> Back
          </Link>
        </Button>
        {loading ? (
          <p className="text-muted-foreground">Loading…</p>
        ) : !c ? (
          <p className="text-muted-foreground">Complaint not found.</p>
        ) : (
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <CardTitle>{c.subject}</CardTitle>
                <span
                  className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-medium ${statusColor(c.status)}`}
                >
                  {c.status}
                </span>
              </div>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <Row label="Complaint ID" value={c.id} />
              <Row label="Category" value={c.category} />
              <Row label="Date" value={new Date(c.created_at).toLocaleString()} />
              <Row label="Customer" value={`${c.customer_name} · ${c.email} · ${c.phone}`} />
              <div>
                <p className="text-xs uppercase tracking-wide text-muted-foreground">Description</p>
                <p className="mt-1 whitespace-pre-wrap text-foreground">{c.description}</p>
              </div>
              <div>
                <p className="text-xs uppercase tracking-wide text-muted-foreground">Admin Reply</p>
                <p className="mt-1 whitespace-pre-wrap text-foreground">
                  {c.admin_reply || <span className="text-muted-foreground">No reply yet.</span>}
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AppShell>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-1 break-all text-foreground">{value}</p>
    </div>
  );
}
