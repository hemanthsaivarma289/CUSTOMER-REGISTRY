export function Footer() {
  return (
    <footer className="border-t bg-card">
      <div className="mx-auto max-w-6xl px-4 py-4 text-center text-sm text-muted-foreground">
        Customer Registry ©2026
      </div>
    </footer>
  );
}
