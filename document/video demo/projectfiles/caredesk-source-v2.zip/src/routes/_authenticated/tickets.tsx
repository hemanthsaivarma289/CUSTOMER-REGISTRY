import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import { StatusBadge, PriorityBadge } from "./dashboard";

export const Route = createFileRoute("/_authenticated/tickets")({
  head: () => ({ meta: [{ title: "Tickets — CareDesk" }] }),
  component: TicketsPage,
});

type Ticket = {
  id: string; subject: string; description: string | null; status: string; priority: string;
  category: string | null; customer_id: string | null; created_at: string;
};
type Customer = { id: string; name: string };

function TicketsPage() {
  const [rows, setRows] = useState<Ticket[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ subject: "", description: "", priority: "medium", category: "", customer_id: "" });

  async function load() {
    setLoading(true);
    const [t, c] = await Promise.all([
      supabase.from("tickets").select("*").order("created_at", { ascending: false }),
      supabase.from("customers").select("id, name").order("name"),
    ]);
    setRows(t.data ?? []);
    setCustomers(c.data ?? []);
    setLoading(false);
  }
  useEffect(() => { load(); }, []);

  async function create(e: React.FormEvent) {
    e.preventDefault();
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return;
    const { error } = await supabase.from("tickets").insert({
      subject: form.subject,
      description: form.description || null,
      priority: form.priority as "low" | "medium" | "high" | "urgent",
      category: form.category || null,
      customer_id: form.customer_id || null,
      created_by: userData.user.id,
    });
    if (error) { toast.error(error.message); return; }
    toast.success("Ticket created");
    setForm({ subject: "", description: "", priority: "medium", category: "", customer_id: "" });
    setOpen(false);
    load();
  }

  const filtered = statusFilter === "all" ? rows : rows.filter((r) => r.status === statusFilter);
  const custMap = new Map(customers.map((c) => [c.id, c.name]));

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Tickets</h1>
          <p className="text-sm text-muted-foreground">Track and manage every support request.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="mr-2 size-4" />New ticket</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>New ticket</DialogTitle></DialogHeader>
            <form onSubmit={create} className="space-y-3">
              <div className="space-y-1.5"><Label>Subject *</Label><Input required value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} /></div>
              <div className="space-y-1.5"><Label>Description</Label><Textarea rows={4} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>Priority</Label>
                  <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {["low", "medium", "high", "urgent"].map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5"><Label>Category</Label><Input placeholder="Billing, Bug, …" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} /></div>
              </div>
              <div className="space-y-1.5"><Label>Customer</Label>
                <Select value={form.customer_id || "none"} onValueChange={(v) => setForm({ ...form, customer_id: v === "none" ? "" : v })}>
                  <SelectTrigger><SelectValue placeholder="Optional" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">— None —</SelectItem>
                    {customers.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter><Button type="submit">Create</Button></DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="mb-4 flex gap-2">
            {["all", "open", "in_progress", "resolved", "closed"].map((s) => (
              <Button key={s} size="sm" variant={statusFilter === s ? "default" : "outline"} onClick={() => setStatusFilter(s)}>
                {s.replace("_", " ")}
              </Button>
            ))}
          </div>
          {loading ? <div className="text-sm text-muted-foreground">Loading…</div> : filtered.length === 0 ? (
            <div className="rounded-md border border-dashed p-10 text-center text-sm text-muted-foreground">No tickets here.</div>
          ) : (
            <div className="divide-y">
              {filtered.map((t) => (
                <Link key={t.id} to="/tickets/$ticketId" params={{ ticketId: t.id }}
                  className="flex items-center justify-between gap-4 py-3 transition-colors hover:bg-muted/50 rounded-md px-2 -mx-2">
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-medium">{t.subject}</div>
                    <div className="mt-0.5 flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
                      <span>{new Date(t.created_at).toLocaleDateString()}</span>
                      {t.category && <span>· {t.category}</span>}
                      {t.customer_id && <span>· {custMap.get(t.customer_id) ?? "Customer"}</span>}
                    </div>
                  </div>
                  <div className="flex shrink-0 gap-2">
                    <PriorityBadge value={t.priority} />
                    <StatusBadge value={t.status} />
                  </div>
                </Link>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
