import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { ArrowLeft, Trash2 } from "lucide-react";
import { StatusBadge, PriorityBadge } from "./dashboard";

export const Route = createFileRoute("/_authenticated/tickets/$ticketId")({
  head: () => ({ meta: [{ title: "Ticket — CareDesk" }] }),
  component: TicketDetail,
});

type Ticket = {
  id: string; subject: string; description: string | null; status: string; priority: string;
  category: string | null; customer_id: string | null; assigned_to: string | null;
  created_at: string; created_by: string;
};
type Interaction = { id: string; message: string; kind: string; author_id: string; created_at: string };
type Profile = { id: string; full_name: string | null };

function TicketDetail() {
  const { ticketId } = Route.useParams();
  const navigate = useNavigate();
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [interactions, setInteractions] = useState<Interaction[]>([]);
  const [profiles, setProfiles] = useState<Record<string, Profile>>({});
  const [customerName, setCustomerName] = useState<string>("");
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const [t, i] = await Promise.all([
      supabase.from("tickets").select("*").eq("id", ticketId).maybeSingle(),
      supabase.from("interactions").select("*").eq("ticket_id", ticketId).order("created_at"),
    ]);
    if (t.error) toast.error(t.error.message);
    setTicket(t.data as Ticket | null);
    setInteractions(i.data ?? []);
    if (t.data?.customer_id) {
      const { data: c } = await supabase.from("customers").select("name").eq("id", t.data.customer_id).maybeSingle();
      setCustomerName(c?.name ?? "");
    }
    const ids = new Set<string>([...(i.data ?? []).map((x) => x.author_id)]);
    if (ids.size) {
      const { data: p } = await supabase.from("profiles").select("id, full_name").in("id", [...ids]);
      const m: Record<string, Profile> = {};
      (p ?? []).forEach((r) => (m[r.id] = r));
      setProfiles(m);
    }
    setLoading(false);
  }
  useEffect(() => { load(); }, [ticketId]);

  async function updateField(patch: Partial<Ticket>) {
    if (!ticket) return;
    const merged = { ...patch, ...(patch.status === "resolved" ? { resolved_at: new Date().toISOString() } : {}) };
    const { error } = await supabase.from("tickets").update(merged as never).eq("id", ticket.id);
    if (error) { toast.error(error.message); return; }
    setTicket({ ...ticket, ...patch });
    toast.success("Updated");
  }

  async function addNote(e: React.FormEvent) {
    e.preventDefault();
    if (!msg.trim()) return;
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return;
    const { error } = await supabase.from("interactions").insert({
      ticket_id: ticketId, message: msg.trim(), author_id: userData.user.id, kind: "note",
    });
    if (error) { toast.error(error.message); return; }
    setMsg("");
    load();
  }

  async function remove() {
    if (!confirm("Delete this ticket?")) return;
    const { error } = await supabase.from("tickets").delete().eq("id", ticketId);
    if (error) { toast.error(error.message + " (admins only)"); return; }
    toast.success("Deleted");
    navigate({ to: "/tickets" });
  }

  if (loading) return <div className="text-sm text-muted-foreground">Loading…</div>;
  if (!ticket) return <div className="text-sm text-muted-foreground">Ticket not found.</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button asChild variant="ghost" size="sm"><Link to="/tickets"><ArrowLeft className="mr-2 size-4" />All tickets</Link></Button>
        <Button variant="ghost" size="sm" onClick={remove}><Trash2 className="mr-2 size-4" />Delete</Button>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="space-y-6 md:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-start justify-between gap-4">
                <div>
                  <CardTitle className="text-xl">{ticket.subject}</CardTitle>
                  <p className="mt-1 text-xs text-muted-foreground">
                    Opened {new Date(ticket.created_at).toLocaleString()}
                    {customerName && ` · for ${customerName}`}
                  </p>
                </div>
                <div className="flex gap-2"><PriorityBadge value={ticket.priority} /><StatusBadge value={ticket.status} /></div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="whitespace-pre-wrap text-sm text-foreground/90">{ticket.description || <span className="text-muted-foreground">No description.</span>}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle>Interaction history</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              {interactions.length === 0 && <div className="text-sm text-muted-foreground">No interactions yet.</div>}
              {interactions.map((it) => (
                <div key={it.id} className="rounded-md border bg-muted/30 p-3">
                  <div className="mb-1 flex justify-between text-xs text-muted-foreground">
                    <span>{profiles[it.author_id]?.full_name ?? "User"}</span>
                    <span>{new Date(it.created_at).toLocaleString()}</span>
                  </div>
                  <p className="whitespace-pre-wrap text-sm">{it.message}</p>
                </div>
              ))}
              <form onSubmit={addNote} className="space-y-2 pt-2">
                <Label htmlFor="msg">Add note</Label>
                <Textarea id="msg" rows={3} value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Log an interaction, update, or internal note…" />
                <Button type="submit" size="sm">Post</Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Manage</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1.5">
                <Label>Status</Label>
                <Select value={ticket.status} onValueChange={(v) => updateField({ status: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["open", "in_progress", "resolved", "closed"].map((s) => <SelectItem key={s} value={s}>{s.replace("_", " ")}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Priority</Label>
                <Select value={ticket.priority} onValueChange={(v) => updateField({ priority: v })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["low", "medium", "high", "urgent"].map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
