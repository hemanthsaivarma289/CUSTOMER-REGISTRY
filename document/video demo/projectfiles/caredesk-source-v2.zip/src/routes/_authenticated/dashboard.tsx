import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Ticket, Users, CheckCircle2, Clock } from "lucide-react";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — CareDesk" }] }),
  component: Dashboard,
});

type Stats = { open: number; inProgress: number; resolved: number; total: number; customers: number };
type RecentTicket = { id: string; subject: string; status: string; priority: string; created_at: string };

function Dashboard() {
  const [stats, setStats] = useState<Stats>({ open: 0, inProgress: 0, resolved: 0, total: 0, customers: 0 });
  const [recent, setRecent] = useState<RecentTicket[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [tickets, customers] = await Promise.all([
        supabase.from("tickets").select("id, subject, status, priority, created_at").order("created_at", { ascending: false }),
        supabase.from("customers").select("id", { count: "exact", head: true }),
      ]);
      const rows = tickets.data ?? [];
      setStats({
        total: rows.length,
        open: rows.filter((t) => t.status === "open").length,
        inProgress: rows.filter((t) => t.status === "in_progress").length,
        resolved: rows.filter((t) => t.status === "resolved" || t.status === "closed").length,
        customers: customers.count ?? 0,
      });
      setRecent(rows.slice(0, 6));
      setLoading(false);
    })();
  }, []);

  const cards = [
    { label: "Open tickets", value: stats.open, icon: Ticket, tone: "text-info" },
    { label: "In progress", value: stats.inProgress, icon: Clock, tone: "text-warning" },
    { label: "Resolved", value: stats.resolved, icon: CheckCircle2, tone: "text-success" },
    { label: "Customers", value: stats.customers, icon: Users, tone: "text-primary" },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Overview</h1>
        <p className="text-sm text-muted-foreground">A snapshot of your customer care activity.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        {cards.map(({ label, value, icon: Icon, tone }) => (
          <Card key={label}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-muted-foreground">{label}</div>
                  <div className="mt-1 text-3xl font-semibold">{loading ? "—" : value}</div>
                </div>
                <Icon className={`size-7 ${tone}`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader><CardTitle>Recent tickets</CardTitle></CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-sm text-muted-foreground">Loading…</div>
          ) : recent.length === 0 ? (
            <div className="rounded-md border border-dashed p-8 text-center text-sm text-muted-foreground">
              No tickets yet. Create one from the Tickets page.
            </div>
          ) : (
            <div className="divide-y">
              {recent.map((t) => (
                <div key={t.id} className="flex items-center justify-between py-3">
                  <div>
                    <div className="font-medium">{t.subject}</div>
                    <div className="text-xs text-muted-foreground">{new Date(t.created_at).toLocaleString()}</div>
                  </div>
                  <div className="flex gap-2">
                    <PriorityBadge value={t.priority} />
                    <StatusBadge value={t.status} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export function StatusBadge({ value }: { value: string }) {
  const map: Record<string, string> = {
    open: "bg-info/15 text-info border-info/30",
    in_progress: "bg-warning/15 text-warning-foreground border-warning/30",
    resolved: "bg-success/15 text-success border-success/30",
    closed: "bg-muted text-muted-foreground border-border",
  };
  return <Badge variant="outline" className={map[value] ?? ""}>{value.replace("_", " ")}</Badge>;
}

export function PriorityBadge({ value }: { value: string }) {
  const map: Record<string, string> = {
    low: "bg-muted text-muted-foreground",
    medium: "bg-info/15 text-info",
    high: "bg-warning/20 text-warning-foreground",
    urgent: "bg-destructive/15 text-destructive",
  };
  return <Badge variant="outline" className={map[value] ?? ""}>{value}</Badge>;
}
