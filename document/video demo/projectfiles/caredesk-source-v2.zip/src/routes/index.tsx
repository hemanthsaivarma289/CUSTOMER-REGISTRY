import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Headphones, Users, Ticket, BarChart3, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CareDesk — Customer Care Registry" },
      { name: "description", content: "Centralized system to record customer interactions, track support tickets, and analyze service trends." },
      { property: "og:title", content: "CareDesk — Customer Care Registry" },
      { property: "og:description", content: "Track customers, tickets, and interactions in one place." },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card/50 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2">
            <div className="grid size-9 place-items-center rounded-lg bg-primary text-primary-foreground">
              <Headphones className="size-5" />
            </div>
            <span className="text-lg font-semibold tracking-tight">CareDesk</span>
          </div>
          <div className="flex gap-2">
            <Button asChild variant="ghost"><Link to="/auth">Sign in</Link></Button>
            <Button asChild><Link to="/auth">Get started</Link></Button>
          </div>
        </div>
      </header>

      <main>
        <section className="mx-auto max-w-6xl px-6 py-20 md:py-28">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 rounded-full border bg-card px-3 py-1 text-xs text-muted-foreground">
              <span className="size-1.5 rounded-full bg-success" /> Customer Care Registry
            </div>
            <h1 className="mt-6 text-4xl font-semibold tracking-tight md:text-6xl">
              Every customer interaction, <span className="text-primary">in one calm place.</span>
            </h1>
            <p className="mt-5 max-w-2xl text-lg text-muted-foreground">
              Record issues, track tickets from open to resolved, and surface trends that make your team faster and your customers happier.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg"><Link to="/auth">Open your registry</Link></Button>
              <Button asChild size="lg" variant="outline"><Link to="/dashboard">Go to dashboard</Link></Button>
            </div>
          </div>

          <div className="mt-20 grid gap-4 md:grid-cols-4">
            {[
              { icon: Users, title: "Customer records", body: "One profile per customer with contact, company, and full history." },
              { icon: Ticket, title: "Support tickets", body: "Create, assign, prioritize, and move through statuses." },
              { icon: BarChart3, title: "Analytics", body: "See open volume, resolution rate, and top categories at a glance." },
              { icon: ShieldCheck, title: "Role-based", body: "Agents handle their queue. Admins manage the whole registry." },
            ].map(({ icon: Icon, title, body }) => (
              <div key={title} className="rounded-xl border bg-card p-5">
                <div className="grid size-10 place-items-center rounded-lg bg-accent text-accent-foreground">
                  <Icon className="size-5" />
                </div>
                <h3 className="mt-4 font-medium">{title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{body}</p>
              </div>
            ))}
          </div>
        </section>
      </main>

      <footer className="border-t py-8 text-center text-sm text-muted-foreground">
        CareDesk — a customer care registry.
      </footer>
    </div>
  );
}
